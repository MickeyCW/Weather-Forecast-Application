package com.example.weatherforecastapplication.data


import com.google.gson.annotations.SerializedName


data class Model(
    @SerializedName("main")
    val weather: WeatherModel,
    @SerializedName("sys")
    val folder: Country,
    @SerializedName("name")
    val nameX: String,


    @SerializedName("list")
    val listData: DataForecast,
    @SerializedName("city")
    val town: DataForecast
)

data class WeatherModel(
    @SerializedName("humidity")
    val humidity: Int,
    @SerializedName("temp")
    val temp: Float,
)

data class Country(
    @SerializedName("country")
    val nameY: String
)


data class DataForecast(
    @SerializedName("dt_txt")
    val dateTime: String,
    @SerializedName("main")
    val weather: WeatherModel,
    @SerializedName("name")
    val nameA: String,
    @SerializedName("country")
    val nameB: String
)


