package com.example.weatherforecastapplication.ui


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.widget.SearchView
import com.example.weatherforecastapplication.R
import com.example.weatherforecastapplication.data.Model
import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    var weatherModelObject: Model? = null
    var cityName = ""


    private fun callApi(city : String, appID : String) {
        val ret = Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val server = ret.create(WeatherAPI::class.java)
        val call =
            server.showSelectedCurrentForecast(city = city, appID = appID)


        call.enqueue(object : Callback<Model> {
            override fun onFailure(call: Call<Model>, t: Throwable) {
                Log.e("Tag", "City not found.")
            }
            override fun onResponse(call: Call<Model>, response: Response<Model>) {
                weatherModelObject = response.body()!!


                val temperatureC = String.format("%.0f",  weatherModelObject!!.weather.temp - 273)
                setupUI(temperatureC = temperatureC)
                setUIOnClickListener(temperatureC = temperatureC )
            }
        })
    }


    private fun setupUI(temperatureC : String) {
        showCity.text = "${weatherModelObject!!.nameX}, ${weatherModelObject!!.folder.nameY}"
        showTemp1.text = "$temperatureC°C"
        showHumid1.text = "${weatherModelObject!!.weather.humidity}% "
    }


    private  fun setUIOnClickListener(temperatureC : String ) {
        changeToF.setOnClickListener {
            val temperatureF =
                String.format("%.0f", ((weatherModelObject!!.weather.temp - 273) * 9 / 5) + 32)
            showTemp1.text = "${temperatureF}°F"
        }
        changeToC.setOnClickListener {
            showTemp1.text = "${temperatureC}°C"
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        callApi(city = "Nonthaburi",appID = "c1f4d11cb3d1ba3b27f588d378e9513d")

        searchCity.setOnQueryTextListener(object : SearchView.OnQueryTextListener {

            override fun onQueryTextChange(s: String): Boolean {
                // make a server call
                return true
            }

            override fun onQueryTextSubmit(s: String): Boolean {
                cityName = s
                callApi(city = s,appID = "c1f4d11cb3d1ba3b27f588d378e9513d")
                println(cityName)
                closeKeyboard(searchCity)
                return true
            }
        })

        changePage1.setOnClickListener {
            val intent = Intent(this, WholeDayActivity::class.java)
            intent.putExtra("CityName", cityName)
            startActivity(intent)
        }
    }
    private fun closeKeyboard(view: SearchView) {
        val keyboard = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        keyboard.hideSoftInputFromWindow(view.windowToken, 0)
    }
}

