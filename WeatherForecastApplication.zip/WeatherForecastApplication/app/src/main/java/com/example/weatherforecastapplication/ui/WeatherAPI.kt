package com.example.weatherforecastapplication.ui

import com.example.weatherforecastapplication.data.DataForecast
import com.example.weatherforecastapplication.data.Model
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherAPI {

    @GET("data/2.5/weather")
    fun showSelectedCurrentForecast(
        @Query("q") city: String,
        @Query("appid") appID: String,
    ): Call<Model>

    @GET("data/2.5/forecast")
    fun showSelectedDailyForecast(
        @Query("q") city2: String,
        @Query("appid") appID2: String,
    ): Call<List<DataForecast>>


}