package com.example.weatherforecastapplication.ui

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.weatherforecastapplication.R
import com.example.weatherforecastapplication.data.DataForecast
import kotlinx.android.synthetic.main.activity_whole_day.*




class WholeDayActivity : AppCompatActivity() {


    var weatherModelObject: DataForecast? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_whole_day)

        val intent = intent
        val cityName = intent.getStringExtra("CityName")



        showCity2.text = "$cityName"


        changePage2.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
    }

}



